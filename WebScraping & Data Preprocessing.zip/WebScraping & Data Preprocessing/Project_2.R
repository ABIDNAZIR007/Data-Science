install.packages(c("stringr", "tokenizers", "stopwords", "textstem", "hunspell"))
install.packages("remotes")
remotes::install_github("unDocUMeantIt/koRpus.lang")
install.packages("rvest")



library(stringr)
library(tokenizers)
library(stopwords)
library(textstem)
library(hunspell)
library(rvest)



data_html <- read_html("https://americanswhotellthetruth.org/portraits/abraham-lincoln/?gad_source=1&gclid=CjwKCAiA6t-6BhA3EiwAltRFGL-HAy4tKFvU8gm59cE1pnJ-TbsNNlcvT0sZ4ZxIwVSl5qERW-Y1SxoCaggQAvD_BwE")
data_direct <- html_nodes(data_html , xpath = "//p[(((count(preceding-sibling::*) + 1) = 3) and parent::*)] | //p[(((count(preceding-sibling::*) + 1) = 1) and parent::*)]")
data_direct
data_direct_text <- html_text(data_direct)
data_direct_text
str(data_direct_text)



clean_text <- str_replace_all(data_direct_text, "[^a-zA-Z\\s]", "")
clean_text <- tolower(clean_text)



tokens <- tokenize_words(clean_text)



tokens_no_stopwords <- lapply(tokens, function(x) x[!x %in% stopwords("en")])



tokens_stemmed <- lapply(tokens_no_stopwords, stem_words)
tokens_lemmatized <- lapply(tokens_no_stopwords, lemmatize_words)



contractions <- c("don't" = "do not", "isn't" = "is not", "you're" = "you are")
clean_text <- str_replace_all(clean_text, contractions)



clean_text <- str_replace_all(clean_text, "[\U0001F600-\U0001F64F]", "")
clean_text <- str_replace_all(clean_text, "[:;=8][oO\\-]?[)D]", "")



tokens_corrected <- lapply(tokens_lemmatized, function(x) 
{
  suggestions <- hunspell_suggest(x)
  sapply(seq_along(x), function(i) ifelse(length(suggestions[[i]]) > 0, suggestions[[i]][1], x[i]))
})



final_text <- lapply(tokens_corrected, paste, collapse = " ")
print(final_text)



preprocessed_text <- unlist(final_text)
file_path <- "A:/IDS/processed_text.txt"
writeLines(preprocessed_text, file_path)
cat("File saved at:", file_path)