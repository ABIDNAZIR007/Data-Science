data <- read.csv("A:/IDS/dataset.csv", header = TRUE, sep = ",")
data
edit(data)



data[data == ""] <- NA
missing_counts <- colSums(is.na(data))
barplot(missing_counts, main = "Missing Values Per Column", xlab = "Columns", ylab = "Number of Missing Values", col = "skyblue", las = 2)



data$Age <- ifelse(is.na(data$Age), mean(data$Age, na.rm = TRUE), data$Age)
mode <- function(column) {
  mode_value <- names(sort(table(column, useNA = "no"), decreasing = TRUE))[1]
  column[is.na(column)] <- mode_value
  return(column)
}
data$Gender <- mode(data$Gender)
data$`Item.Purchased` <- mode(data$`Item.Purchased`)
data$`Frequency.of.Purchases` <- mode(data$`Frequency.of.Purchases`)
data <- na.omit(data)
edit(data)



duplicates <- data[duplicated(data), ]
data <- data[!duplicated(data), ]
edit(data)



class_counts <- table(data$Gender)
print("Class distribution before balancing:")
print(class_counts)
balance_dataset <- function(data, column_name) {
  column <- data[[column_name]]
  majority_class <- names(which.max(table(column)))
  minority_class <- names(which.min(table(column)))
  
  majority_data <- data[column == majority_class, ]
  minority_data <- data[column == minority_class, ]
  
  minority_oversampled <- minority_data[sample(nrow(minority_data), nrow(majority_data), replace = TRUE), ]
  
  balanced_data <- rbind(majority_data, minority_oversampled)
  return(balanced_data)
}
data_balanced <- balance_dataset(data, "Gender")
class_counts_balanced <- table(data_balanced$Gender)
print("Class distribution after balancing:")
print(class_counts_balanced)



class_counts <- table(data$Gender)
print("Class distribution before balancing:")
print(class_counts)
balance_dataset <- function(data, column_name) 
{
  column <- data[[column_name]]
  levels <- unique(column)
  
  majority_class <- names(which.max(table(column)))
  minority_class <- names(which.min(table(column)))
  
  majority_data <- data[column == majority_class, ]
  minority_data <- data[column == minority_class, ]
  
  majority_undersampled <- majority_data[sample(nrow(majority_data), nrow(minority_data), replace = FALSE), ]
  
  balanced_data <- rbind(majority_undersampled, minority_data)
  
  return(balanced_data)
}
data_balanced <- balance_dataset(data, "Gender")
class_counts_balanced <- table(data_balanced$Gender)
print("Class distribution after balancing:")
print(class_counts_balanced)



print(paste("Original Dataset: Rows =", nrow(data), ", Columns =", ncol(data)))
filtered_Age <- data[data$Age > 30, ]
print(paste("Filtered Rows (Age > 30):", nrow(filtered_Age)))
filtered_complete_after_missing <- data[complete.cases(data), ]
print(paste("Rows After Removing Missing Values:", nrow(filtered_complete_after_missing)))
filtered_data_columns <- data[, c("Age", "Gender")]
print(paste("Filtered Columns: Columns =", ncol(filtered_data_columns)))



print("Unique values in Gender before conversion:")
print(unique(data$Gender))
data$Gender <- ifelse(data$Gender == "Male", 1, ifelse(data$Gender == "Female", 0, NA))
print("Unique values in Gender after conversion:")
print(unique(data$Gender))
edit(data)



print("Summary of Age before conversion:")
print(summary(data$Age))
data$AgeGroup <- cut(data$Age, breaks = c(0, 35, 60, Inf), labels = c("Youth", "Middle-aged", "Oldage"), right = FALSE)
print("Unique values in AgeGroup after conversion:")
print(unique(data$AgeGroup))
edit(data)



print("Summary of Age before normalization:")
print(summary(data$Age))
data$NormalizedAge <- (data$Age - min(data$Age, na.rm = TRUE)) / (max(data$Age, na.rm = TRUE) - min(data$Age, na.rm = TRUE))
print("Summary of Normalized Age:")
print(summary(data$NormalizedAge))
edit(data)



Q1 <- quantile(data$Age, 0.25, na.rm = TRUE)
Q3 <- quantile(data$Age, 0.75, na.rm = TRUE)
IQR_value <- Q3 - Q1
lower_bound <- Q1 - 1.5 * IQR_value
upper_bound <- Q3 + 1.5 * IQR_value
outliers <- data$Age < lower_bound | data$Age > upper_bound
print("Outlier Rows in Age:")
print(data[outliers, ])
data$Age[outliers] <- NA
median_age <- median(data$Age, na.rm = TRUE)
data$Age[outliers] <- median_age
print("Summary of Age after handling outliers:")
print(summary(data$Age))



print("Unique values in Gender before validation:")
print(unique(data$Gender))
valid_genders <- c("Male", "Female")
data$Gender[!(data$Gender %in% valid_genders)] <- NA
print("Unique values in Gender after validation:")
print(unique(data$Gender))
